SELECT LoincNum, Value, Unit, ValidStartTime, TransactionInsertionTime
FROM Measurements
WHERE PatientId = ? AND LoincNum = ? AND ValidStartTime = ?;