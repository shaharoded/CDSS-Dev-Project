-- Purpose: Inserts 1 record into the Patients table -> A new record

INSERT INTO Patients (PatientId, FirstName, LastName) VALUES (?, ?, ?);
